package com.newer.dao;

import com.newer.pojo.Author;

import java.util.List;

public interface AuthorMapper {
    List<Author> findAll();
}
