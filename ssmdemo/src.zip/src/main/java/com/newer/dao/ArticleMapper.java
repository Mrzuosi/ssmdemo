package com.newer.dao;

public interface ArticleMapper {

}
