package com.newer.dao;

import com.newer.pojo.ArticleCommt;

import java.util.List;

public interface ArticleCommtMapper {
    List<ArticleCommt> findAll();
}
