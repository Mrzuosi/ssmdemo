package com.newer.service;

import com.newer.pojo.Author;

import java.util.List;

public interface AuthorService {

    List<Author> findAll();
}
